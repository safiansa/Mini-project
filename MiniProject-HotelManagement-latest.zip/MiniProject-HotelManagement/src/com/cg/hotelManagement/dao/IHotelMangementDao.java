package com.cg.hotelManagement.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.dto.roomDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public interface IHotelMangementDao {
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();

	public UserDetails userLogin(String userName) throws HotelManagementException;
	
	public void addUser(UserDetails userDetails);
	
	public List<Hotels> viewAllHotels();
	
	public List<bookingDetails> viewBookingDetailsFromDate(LocalDate date);
	
	public List<Hotels> searchHotels(String city,int minPrice,int maxPrice,int rating); //rohitash
	
	public List<String> viewGuestListSpecificHotels(String hotellId); 	//neha
	
	public List<bookingDetails> viewBookingSpecificHotel(String hotelId);	//neha

	public void addHotel(Hotels hotelDetails);
	
	public void deleteHotel(String hId);
	
	public void updateHotel(Hotels hotelDetails);
	
	public void addRoom(roomDetails rumDetails);
	
	public void updateRoom(roomDetails rumDetails);

	public void updateTableBeforeBooking(bookingDetails bkDetailsObj); //bhurra

	public void update(bookingDetails bkDetails); //bhurra

	public roomDetails checkAvailability(bookingDetails bkDetails); //bhurra

	public void bookHotel(bookingDetails bkDetails); //bhurra
	public int getAmountToBePaid(bookingDetails bkDetails) ;

	
}

package com.cg.hotelManagement.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.dto.roomDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public class HotelManagementDaoImpl implements IHotelMangementDao {

	private EntityManager entityManager;
	
	public HotelManagementDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		entityManager.flush();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}
	
	@Override
	public UserDetails userLogin(String userId) throws HotelManagementException{
		entityManager.getTransaction().begin();
		try{
		UserDetails userDetails=entityManager.find(UserDetails.class,userId);
		entityManager.getTransaction().commit();
		return userDetails;
		}catch(NullPointerException e){
			throw new HotelManagementException("This User Does Not Exist");
		}
		
	}

	@Override
	public void addUser(UserDetails userDetails) {
		entityManager.getTransaction().begin();
		entityManager.persist(userDetails);
		entityManager.getTransaction().commit();
		
		System.out.println("You are registered Successfully");
	}

	@Override
	public void addHotel(Hotels hotelDetails) {
		entityManager.getTransaction().begin();
		entityManager.persist(hotelDetails);
		entityManager.getTransaction().commit();
		System.out.println("Hotel added successfully with Hotel ID ::"+hotelDetails.getHotelId());
	}
	
	@Override
	public void addRoom(roomDetails rumDetails) {
		entityManager.getTransaction().begin();
		entityManager.persist(rumDetails);
		entityManager.getTransaction().commit();
		
		System.out.println("A new room added to dataBase.");
	}
	
	public void modifyRoom(roomDetails rumDetails)
	{
		entityManager.getTransaction().begin();
		entityManager.merge(rumDetails);
		entityManager.getTransaction().commit();

	}
	
	public void deleteRoom(String roomID)
	{		
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery(
				"DELETE FROM roomDetails h WHERE h.roomId =:p");
		query.setParameter("p", roomID).executeUpdate();
		entityManager.getTransaction().commit();
		
		System.out.println("Room with ID <<"+roomID+">> deleted");
	}
	
	@Override
	public List<bookingDetails> viewBookingDetailsFromDate(LocalDate date2) {
		int d=date2.getDayOfMonth();
		int y=date2.getYear();
		int m=date2.getMonthValue();
		Date date=new Date(y-1900, m-1, d);
		beginTransaction();
		List<bookingDetails> bookingDetails=new ArrayList<bookingDetails>();
        String querry=new String("select bookingDetails from bookingDetails bookingDetails"+
		                         " where bookingDetails.bookedFrom<=:pDate"+
        		                   " and bookingDetails.bookedTo>=:pDate");	
        TypedQuery<bookingDetails> quer=entityManager.createQuery(querry,bookingDetails.class);
		quer.setParameter("pDate", date);
		return quer.getResultList();
	}

	@Override
	public List<Hotels> searchHotels(String city, int minPrice,
			int maxPrice, int rating) {
			beginTransaction();
			List<bookingDetails> bookingDetails=new ArrayList<bookingDetails>();
	        String querry=new String("select hotel from Hotels hotel"+
			                         " where hotel.city=:pCity and "
			                         + "hotel.avgRatePerNight<=:pMaxPrice and "+
			                         "hotel.avgRatePerNight>=:pMinPrice"+
	        		                   " and hotel.rating>=:pRating");	
	        TypedQuery<Hotels> quer=entityManager.createQuery(querry,Hotels.class);
			quer.setParameter("pMinPrice",minPrice);
			quer.setParameter("pMaxPrice",maxPrice);
			quer.setParameter("pRating",rating);
			quer.setParameter("pCity",city);
			return quer.getResultList();
	}

	@Override
	public void bookHotel(bookingDetails bkDetails)
	{
		beginTransaction();
		entityManager.persist(bkDetails);
		entityManager.getTransaction().commit();
	}
	
	
	@Override
	public roomDetails checkAvailability(bookingDetails bkDetails) {

		//beginTransaction();
		String query=new String("select rd from roomDetails rd where rd.hotelId=:hId and rd.roomId=:rId");
		TypedQuery<roomDetails> quer=entityManager.createQuery(query,roomDetails.class);
		quer.setParameter("hId",bkDetails.getHotelId());
		quer.setParameter("rId",bkDetails.getRoomId());

		roomDetails rDetails=new roomDetails();
		rDetails=quer.getSingleResult();
		return rDetails;

	}
	
	@Override
	public void update(bookingDetails bkDetails) 
	{
		beginTransaction();
		String query=new String("update roomDetails rd " +
				"set rd.availability=rd.availability-1 "+
				"where rd.roomId=:bkRId and rd.hotelId=:bkHId");

		Query qur=  entityManager.createQuery(query);
		qur.setParameter("bkRId",bkDetails.getRoomId());
		qur.setParameter("bkHId",bkDetails.getHotelId());

		int status= qur.executeUpdate();


		entityManager.getTransaction().commit();


	}
	
	@Override
	public void updateTableBeforeBooking(bookingDetails bkDetailsObj)
	{
		beginTransaction();
		String query=new String("select bd from bookingDetails bd where "+
				" bd.roomId=:rId and bd.hotelId=:bkHId");
		TypedQuery<bookingDetails> quer=entityManager.createQuery(query,bookingDetails.class);

		quer.setParameter("rId",bkDetailsObj.getRoomId());
		quer.setParameter("bkHId",bkDetailsObj.getHotelId());
		bookingDetails bDetailsFrmDb=quer.getSingleResult();
		try{	
			Date dtFrmObj=bkDetailsObj.getBookedFrom();  //date from Object
			Date dtFrmDb=bDetailsFrmDb.getBookedTo();     //date we retreived from DataBase

			System.out.println("Date is "+dtFrmDb);
			//from                         //to
			Period prd=(dtFrmDb.toLocalDate()).until(dtFrmObj.toLocalDate());
			int prdInDays=prd.getDays();

			if(prdInDays>1){

				String query1=new String("update roomDetails rd " +
						"set rd.availability=rd.availability+1 "+
						"where rd.roomId=:bkRId ");

				Query qur=  entityManager.createQuery(query1);
				qur.setParameter("bkRId",bDetailsFrmDb.getRoomId());
				qur.executeUpdate();
				entityManager.getTransaction().commit();
			}
			else
			{
				System.out.println("there are no records to be updated as period is less than1");
			}

		}
		catch(Exception e)
		{
			System.err.println("entered room Id and hotelId is not yet booked " +
					"  we cannot retreive row from Database"+
					" OR multiple records cannot be retrieved");
		}


	}

	@Override
	public List<String> viewGuestListSpecificHotels(String hotellId) {
//		beginTransaction();
//		//List<UserDetails> guestList=new ArrayList<UserDetails>();
//		TypedQuery<UserDetails> query = entityManager.createQuery("SELECT e FROM user_details where e.hotelId"+hotellId, UserDetails.class);
//		entityManager.getTransaction().commit();
//		return query.getResultList();
		
		String qStr = "SELECT guestList.userId FROM bookingDetails guestList WHERE hotelId ='"+hotellId+"'";
		TypedQuery<String> query = entityManager.createQuery(qStr, String.class);
		
		List<String> uIDList= query.getResultList();
		List<String> uNameList=null;
		for(String uId:uIDList){
			String q="SELECT gList.userName FROM UserDetails gList WHERE userId='"+uId+"'";
			Query query1 = entityManager.createQuery(q,String.class);
			System.out.println("User name ::"+query1.getSingleResult());
			//uNameList.add((String) query1.getSingleResult());
		}
		return uNameList;
	}

	@Override
	public List<bookingDetails> viewBookingSpecificHotel(String hotelId) {
		beginTransaction();
		TypedQuery<bookingDetails> query = entityManager.createQuery("SELECT bdetails FROM bookingDetails bdetails WHERE bdetails.hotelId='"+hotelId+"'", bookingDetails.class);
		entityManager.getTransaction().commit();
		return query.getResultList();
	}

	@Override
	public void deleteHotel(String hId) {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery(
				"DELETE FROM Hotels h WHERE h.hotelId =:p");
		query.setParameter("p", hId).executeUpdate();
		entityManager.getTransaction().commit();
		
		System.out.println("Hotel with ID <<"+hId+">> deleted");
	}

	@Override
	public void updateHotel(Hotels hotelDetails) {
		entityManager.getTransaction().begin();
		entityManager.merge(hotelDetails);
		entityManager.getTransaction().commit();
		
		System.out.println("Hotel with ID <<"+hotelDetails.getHotelId()+">> updated");
	}

	@Override
	public void updateRoom(roomDetails rumDetails) {
		entityManager.getTransaction().begin();
		entityManager.merge(rumDetails);
		entityManager.getTransaction().commit();
		
		System.out.println("Room with ID <<"+rumDetails.getRoomId()+">> updated");
	}

	@Override
	public List<Hotels> viewAllHotels() {
		
		String qStr = "SELECT hotels FROM Hotels hotels";
		TypedQuery<Hotels> query = entityManager.createQuery(qStr, Hotels.class);
		return query.getResultList();
	}


	@Override
	public int getAmountToBePaid(bookingDetails bkDetails) {
		// TODO Auto-generated method stub
		return 0;
	}
	}



package com.cg.hotelManagement.cleint;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.dto.roomDetails;
import com.cg.hotelManagement.exception.HotelManagementException;
import com.cg.hotelManagement.service.HotleManagementServiceImpl;

public class HotelManagementClient {

	public static void main(String[] args)  {
		Scanner sc= new Scanner(System.in);

		HotleManagementServiceImpl hotelMangementService=new HotleManagementServiceImpl();
		UserDetails userDetails=new UserDetails();
		Hotels hotels=new Hotels();
		roomDetails rDetails =new roomDetails();

		System.out.println("WELCOME TO HOTEL MANAGEMENT SYSTEM");
		System.out.println("1.Admin");
		System.out.println("2. Customer/HotelEmployee");
		System.out.println("3. Exit.");
		System.out.println("Select one of the above :: ");

		int firstChoice=sc.nextInt();
		switch(firstChoice){
		case 1:{

			System.out.println("You selected admin.......Please Login."); 	//ADMIN LOGIN since there can be only one admin --> so values are hardcoded in service layer.
			System.out.println("Enter Admin LoginID ::");
			String adminId = sc.next();
			System.out.println("Enter Admin Password :: ");
			String adminPassword= sc.next();

			if(hotelMangementService.adminLogin(adminId, adminPassword)==false){
				System.err.println("You entered wrong admin credentials.");	
			}
			else{ 
				System.out.println("Welcome Admin...Select one of the following..");
				System.out.println("1. Hotels management (add/delete/modify hotel details..)");
				System.out.println("2. Rooms management (add/delete/modify room details..)");
				System.out.println("3. Generate various reports.");
				System.out.println("4. Exit");

				int secondChoice=sc.nextInt();
				switch(secondChoice){
				case 1:{
					System.out.println("You selected to manage hotels. ");
					System.out.println("Please select one of the following operation ::");
					System.out.println("1. Add a new hotel to dataBase.");
					System.out.println("2. Delete a hotel from dataBase");
					System.out.println("3. Update a hotel detail in dataBase.");
					System.out.println("4.Exit.");

					int thirdChoice=sc.nextInt();
					switch(thirdChoice)
					{
					case 1:{
						System.out.println("Want to enter a new hotel to dataBase?");
						System.out.println("Enter Hotel details ::");

						System.out.println("Enter hotel ID ::");
						String hId=sc.next();
						hotels.setHotelId(hId);

						System.out.println("Enter city ::");
						String cty=sc.next();
						hotels.setCity(cty);

						System.out.println("Enter hotel Name ::");
						String hName=sc.next();
						hotels.setHotelName(hName);

						System.out.println("Enter hotel address ::");
						String addrs=sc.next();
						hotels.setAddress(addrs);

						System.out.println("Enter a short decription of hotel ::");
						String desc=sc.next();
						hotels.setDescription(desc);

						System.out.println("Enter avg rate per night for this hotel ::");
						int arpn=sc.nextInt();
						hotels.setAvgRatePerNight(arpn);

						System.out.println("Enter primary contact number ::");
						String pno = sc.next();
						hotels.setPhone1(pno);

						System.out.println("Enter secondry contact number::");
						String sno = sc.next();
						hotels.setPhone2(sno);

						System.out.println("Enter rating of hotel ::");
						int rating = sc.nextInt();
						hotels.setRating(rating);

						System.out.println("Enter fax details ::");
						String fax = sc.next();
						hotels.setFax(fax);

						// adding a new hotel to dataBase
						hotelMangementService.addHotel(hotels);
						break;	
					}
					case 2:{
						System.out.println("You selected to delete a hotel from dataBase ::");
						System.out.println("Enter a hotel ID to delete from dataBase ::");
						String hId=sc.next();
						//delete the hotel here.
						hotelMangementService.deleteHotel(hId);
						break;	
					}
					case 3:{
						System.out.println("You selected to update a existing hotel in dataBase ");

						System.out.println("Enter hotel ID ::");
						String hId=sc.next();
						hotels.setHotelId(hId);

						System.out.println("Enter city ::");
						String cty=sc.next();
						hotels.setCity(cty);

						System.out.println("Enter hotel Name ::");
						String hName=sc.next();
						hotels.setHotelName(hName);

						System.out.println("Enter hotel address ::");
						String addrs=sc.next();
						hotels.setAddress(addrs);

						System.out.println("Enter a short decription of hotel ::");
						String desc=sc.next();
						hotels.setDescription(desc);

						System.out.println("Enter avg rate per night for this hotel ::");
						int arpn=sc.nextInt();
						hotels.setAvgRatePerNight(arpn);

						System.out.println("Enter primary contact number ::");
						String pno = sc.next();
						hotels.setPhone1(pno);

						System.out.println("Enter secondry contact number::");
						String sno = sc.next();
						hotels.setPhone2(sno);

						System.out.println("Enter rating of hotel ::");
						int rating = sc.nextInt();
						hotels.setRating(rating);

						System.out.println("Enter fax details ::");
						String fax = sc.next();
						hotels.setFax(fax);

						//hotel details updated here.
						hotelMangementService.updateHotel(hotels);
						break;	
					}
					case 4:{
						System.out.println("You choose to exit.");
						break;	
					}
					default:{
						System.out.println("You entered a wrong value...Please try again.");
						break;	
					}
					}
					break;
				}
//NEHA
				case 2:{
					System.out.println("To manage the Room Details,please select one of the following operation ::");
					System.out.println("1. Add a new room to dataBase.");
					System.out.println("2. Delete a room from dataBase");
					System.out.println("3. Update room details in dataBase.");
					System.out.println("4.Exit.");
					int Choice=sc.nextInt();
					switch(Choice)
					{
					case 1:{
						System.out.println("Want to enter a new room to dataBase?");
						System.out.println("Enter Room details ::");

						System.out.println("Enter room ID ::");
						String rId=sc.next();
						rDetails.setRoomId(rId);

						System.out.println("Enter hotel ID ::");
						String hId=sc.next();
						rDetails.setHotelId(hId);

						System.out.println("Enter room No ::");
						String rNo=sc.next();
						rDetails.setRoomNo(rNo);

						System.out.println("Enter room type ::");
						String rType=sc.next();
						rDetails.setRoomType(rType);

						System.out.println("Enter the rate for per night ::");
						int pnr=sc.nextInt();
						rDetails.setPerNightRate(pnr);

						System.out.println("Enter availability of room ::");
						int avl=sc.nextInt();
						rDetails.setAvailability(avl);

						//adding a new room to dataBase
						hotelMangementService.addRoom(rDetails);
						break;	
					}
					case 2:{
						System.out.println("You selected to delete a room from dataBase ::");
						System.out.println("Enter the room ID to delete from dataBase ::");
						String roomID=sc.next();
						
						//delete a room from dataBase
						hotelMangementService.deleteRoom(roomID);
						break;	
					}
					case 3:{
						System.out.println("You selected to update an existing room in dataBase ");

						System.out.println("Enter room ID ::");
						String rId=sc.next();
						rDetails.setRoomId(rId);
						
						System.out.println("Enter hotel ID ::");
						String hId=sc.next();
						rDetails.setHotelId(hId);

						System.out.println("Enter room No ::");
						String rNo=sc.next();
						rDetails.setRoomNo(rNo);

						System.out.println("Enter room type ::");
						String rType=sc.next();
						rDetails.setRoomType(rType);

						System.out.println("Enter the rate for per night ::");
						int pnr=sc.nextInt();
						rDetails.setPerNightRate(pnr);

						System.out.println("Enter availability of this room ::");
						int avl=sc.nextInt();
						rDetails.setAvailability(avl);

						// update a room in database
						hotelMangementService.updateRoom(rDetails);
						break;	
					}
					case 4:{
						System.out.println("You choose to exit.");
						break;	
					}
					
					default:{
						System.out.println("You entered a wrong value...Please try again.");
						break;	
					}
					
					}
					break;
				}
				case 3:{
					System.out.println("Please select any of the options listed below to view details ::");
					System.out.println("1. View List of Hotels");
					System.out.println("2. View Bookings of specific hotel");
					System.out.println("3. View guest list of specific hotel");
					System.out.println("4. View bookings for specified date");
					System.out.println("5. Exit.");
					int Choice=sc.nextInt();
					switch(Choice)
					{
//NEHA					
					case 1:{
						System.out.println("Want to view list of hotels?");
						
						//view list of all hotels 
						System.out.println("Here is the List of all hotels ::"+hotelMangementService.viewAllHotels());
						break;
					}
					case 2:{
						System.out.println("Want to view bookings of specific hotel?");
						System.out.println("Enter Hotel Id ::");
						String hotelId=sc.next();
						
						//view bookings of specifc hotels
						System.out.println("Bookings of hotel <<"+hotelId+">>");
						System.out.println(hotelMangementService.viewBookingSpecificHotel(hotelId));
						break;
					}
					case 3:{
						System.out.println("Want to view guest list of specific hotel?");
						System.out.println("Enter Hotel Id ::");
						String hotelId=sc.next();
						System.out.println("GuestList of Hotel ID <<"+hotelId+">>");
						System.out.println(hotelMangementService.viewGuestListSpecificHotels(hotelId));
						//view guest list of specific hotels.
						break;
					}
					case 4:{
						System.out.println("Want to view bookings of specific date?");
						System.out.println("Enter date(d/MM/yyyy) ::");
						String bDate=sc.next();
						
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");

						//convert String to LocalDate
						LocalDate localDate = LocalDate.parse(bDate, formatter);
						System.out.println(hotelMangementService.viewBookingDetailsFromDate(localDate));
					}
						
					}
						
					break;
				}
				case 4:{
					System.out.println("You choose to exit from application.");
					break;
				}
				default:
					System.out.println("You entered a wrong value...Please try again.");
					break;
				}
			}
			break;
		}
		case 2:{
			
			System.out.println("You selected customer/hotelEmployee");
			System.out.println("1.Login");
			System.out.println("2. Register");

			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
			{
				System.out.println("Enter UserId");
				String userIdLogin=sc.next();
				System.out.println("Enter Password");
				String userPassword=sc.next();
			
				int i=0;
				try {
					i = hotelMangementService.userLogin(userIdLogin, userPassword);
				} catch (HotelManagementException e) {
					System.err.println("Wrong userID and Password");
				}
				if(i==1){
						System.out.println("1.Search Hotels");
						System.out.println("2. Book Hotel Room");
						System.out.println("3. View Bookig Status");
						
						int choicee=sc.nextInt();

						switch(choicee)
						{
						case 1:{
							System.out.println("Search a Hotel Room");
							
							System.out.println("Enter city ::");
							String city=sc.next();
							System.out.println("Enter min  price ::");
							int minPrice=sc.nextInt();
							System.out.println("Enter max  price ::");
							int maxPrice=sc.nextInt();
							System.out.println("Enter rating ::");
							int rating=sc.nextInt();
							
						// sesrch a hotel room-->it will return a list
							System.out.println("This is the hotels List as per your needs ::");
							System.out.println(hotelMangementService.searchHotels(city, minPrice, maxPrice, rating));
							break;
						}
						case 2:{

							System.out.println("Book a Hotel Room");
//bhurra
							System.out.println("Enter your Booking Id :: ");
							String bookingId=sc.next();

							System.out.println("Enter HotelId you want to Book :: ");
							String hotelId=sc.next();

							System.out.println("Enter RoomId you want to Book :: ");
							String roomId=sc.next();

							System.out.println("Enter your userId :: ");
							String userId=sc.next();

							System.out.println("Enter the date you want to book From ");

							LocalDate date1;
							DateTimeFormatter formatter=
									DateTimeFormatter.ofPattern("yyyy-MM-dd");

							String dateF=sc.next();			
							date1=LocalDate.parse(dateF,formatter);
							Date bookedFrom=Date.valueOf(date1);

							System.out.println("Enter till which date  you want to book  ");
							LocalDate date2;
							DateTimeFormatter formatter1=
									DateTimeFormatter.ofPattern("yyyy-MM-dd");

							String dateT=sc.next();			
							date2=LocalDate.parse(dateT,formatter1);
							Date bookedTo=Date.valueOf(date2);


								System.out.println("difference between days is");
							Period prd=( bookedFrom.toLocalDate()).until( bookedTo.toLocalDate());
								System.out.println("Days:"+prd.getDays());

							System.out.println("Enter No of adults ");
							int noOfAdults=sc.nextInt();

							System.out.println("Enter no of children ");
							int  noOfChildren=sc.nextInt();


							bookingDetails bkDetails=new bookingDetails();
							bkDetails.setBookingId(bookingId);
							bkDetails.setHotelId(hotelId);
							bkDetails.setRoomId(roomId);
							bkDetails.setUserId(userId);
							bkDetails.setBookedFrom(bookedFrom);
							bkDetails.setBookedTo(bookedTo);
							bkDetails.setNoOfAdults(noOfAdults);
							bkDetails.setNoOfChildren(noOfChildren);

							System.out.println("The amount  you have to pay is ");


							//Calling service layer
							int amtToPaid=hotelMangementService.getAmountToBePaid(bkDetails);

							int amountToBePaid=(prd.getDays()*amtToPaid);

							System.out.println(amountToBePaid);


							bkDetails.setAmount(amountToBePaid);

							System.out.println("details succesfully inserted into bkdetails object "+bkDetails +"\n");

							//Calling Service Layer
							int status=hotelMangementService.bookHotel(bkDetails);

						System.out.println("hotel booked  "+status);

							break;
						}
						case 3:{
							System.out.println("View Booking Status");

							//Calling Service Layer
							//Not Sure About This one
							//	int status=hotelMangementService.getStatus(bkDetails);
							break;
						}

			}
			}
				else{
					System.err.println("Wrong userID and Password.");
				}
				break;
			}
			case 2: 
			{
				System.out.println("Welcome to Register User Details");
				System.out.println("Enter User Details");
				System.out.println("Enter User Id");
				String userId=sc.next();
				System.out.println("Enter User Password");
				String password=sc.next();
				System.out.println("Enter User Role");
				String userRole=sc.next();
				System.out.println("Enter User Name");
				String userName=sc.next();
				System.out.println("Enter User Mobile No");
				String userMobileNo=sc.next();
				System.out.println("Enter User Phone");
				String userPhone=sc.next();
				System.out.println("Enter User Address");
				String userAddress=sc.next();
				System.out.println("Enter User Email");
				String userEmail=sc.next();
				
				UserDetails userObj=new UserDetails(userId,password,userRole,userName,userMobileNo,userPhone,userAddress,userEmail);
				
				hotelMangementService.addUser(userObj);
				break;
			}
			}
		break;
		}
		case 3:{
			System.out.println("Thankyou for using our services......Visit Again.");
			break;
		}
		default:{
			System.err.println("You entered a wrong value...Please try again.");
			break;
		}
		}
	}
}

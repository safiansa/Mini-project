package com.cg.hotelManagement.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.hotelManagement.dao.HotelManagementDaoImpl;
import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.dto.roomDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public class HotleManagementServiceImpl implements IHotelManagementService {

	HotelManagementDaoImpl hotelManagementDao=new HotelManagementDaoImpl();
	
	public boolean adminLogin(String userName,String password){
		if(userName.equalsIgnoreCase("system") && password.equals("Capgemini123"))
			return true;
		else 
			return false;
	}

	@Override
	public int getAmountToBePaid(bookingDetails bkDetails) {
		
		roomDetails rumDetails=hotelManagementDao.checkAvailability(bkDetails);
		int amountToBePaid=rumDetails.getPerNightRate();
		return amountToBePaid;
	}
	
	@Override
	public int userLogin(String userName, String Password) throws HotelManagementException {
		UserDetails  userDetails=hotelManagementDao.userLogin(userName);
		try{
		String uId = userDetails.getUserId();
		String pwd= userDetails.getPassword();
		
		if(userName.equalsIgnoreCase(uId) && Password.equals(pwd))
			return 1;
		else 
			return 0;
		}catch(NullPointerException e){
			throw new HotelManagementException("User does not exist");
		}
	}
	

	@Override
	public List<Hotels> viewAllHotels() {
		return hotelManagementDao.viewAllHotels();
	}

	@Override
	public List<bookingDetails> viewBookingSpecificHotel(String hotelId) {	//neha
		return hotelManagementDao.viewBookingSpecificHotel(hotelId);
	}

	@Override
	public List<String> viewGuestListSpecificHotels(String hotellId) {	//neha
		return hotelManagementDao.viewGuestListSpecificHotels(hotellId); 
	}

	@Override
	public List<bookingDetails> viewBookingDetailsFromDate(LocalDate date) {
		return hotelManagementDao.viewBookingDetailsFromDate(date);
	}

	@Override
	public List<Hotels> searchHotels(String city, int minPrice,int maxPrice,
			int rating) {
		return hotelManagementDao.searchHotels(city, minPrice, maxPrice, rating);
	}

	@Override
	public int bookHotel(bookingDetails bkDetails) {
		
		//hotelManagementDao.updateTableBeforeBooking(bkDetails);
		roomDetails rumDetails=hotelManagementDao.checkAvailability(bkDetails);

		
		
		int noOfRoomsAvailable=rumDetails.getAvailability();
		
		System.out.println("Available no of rooms is "+noOfRoomsAvailable);

		if(noOfRoomsAvailable>0)
		{
			/*Date bookedFrom = bkDetails.getBookedFrom();
			Date bookedTo = bkDetails.getBookedTo();
			Period prd=( bookedFrom.toLocalDate()).until( bookedTo.toLocalDate());
			int prdInDays=prd.getDays();*/
			
				
				hotelManagementDao.bookHotel(bkDetails);
				System.out.println("we are going to update ");
				System.out.println("book details is"+bkDetails);
				hotelManagementDao.update(bkDetails);
				System.out.println("we  updated ");
				return 1;
		
		}

		else return 0;

	}

	@Override
	public int bookingStatus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void addUser(UserDetails userDetails) {
		hotelManagementDao.addUser(userDetails);
	}

	@Override
	public void addHotel(Hotels hotel) {
		hotelManagementDao.addHotel(hotel);
	}

	@Override
	public void updateHotel(Hotels hotel) {
		hotelManagementDao.updateHotel(hotel);
		
	}

	@Override
	public void deleteHotel(String hotelID) {
		hotelManagementDao.deleteHotel(hotelID);
		
	}

	@Override
	public void addRoom(roomDetails rDetails) {
		hotelManagementDao.addRoom(rDetails);
	}

	@Override
	public void updateRoom(roomDetails rDetails) {
		hotelManagementDao.updateRoom(rDetails);
		
	}

	@Override
	public void deleteRoom(String roomID) {
		hotelManagementDao.deleteRoom(roomID);
	}
}
